#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""一键启动三只桌宠。

每只桌宠跑在独立进程里（tkinter 主循环不能共享），本脚本作为守护进程
把它们拉起来并保活：任一只意外退出时会被重新拉起，Ctrl+C 全部关闭。

用法：
    python launch_pets.py            # 启动三只
    python launch_pets.py --no-watch # 只启动，不做自动重启
"""
import argparse
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.abspath(__file__))

ROLES = [
    ("shaolan", "shaolan_pet.py"),
    ("sunpet", "sun_pet.py"),
    ("fengge", "feng_pet.py"),
]


def spawn(script, log_dir):
    """启动一只桌宠；优先用 pythonw 以免弹出控制台窗口。"""
    exe = sys.executable
    if os.name == "nt":
        pythonw = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(pythonw):
            exe = pythonw
    log = open(os.path.join(log_dir, "launcher.log"), "ab")
    return subprocess.Popen(
        [exe, script],
        cwd=ROOT,
        stdout=log,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        close_fds=True,
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-watch", action="store_true",
                    help="不自动重启意外退出的桌宠")
    args = ap.parse_args()

    log_dir = os.path.join(ROOT, "logs")
    os.makedirs(log_dir, exist_ok=True)

    procs = {}   # role -> [Popen, script]
    for role, script in ROLES:
        procs[role] = [spawn(script, log_dir), script]
        print("已启动 %s (%s)" % (role, script), flush=True)

    print("\n三只桌宠已就位，Ctrl+C 全部退出。\n", flush=True)

    try:
        while True:
            time.sleep(2)
            if args.no_watch:
                continue
            for role, (proc, script) in list(procs.items()):
                if proc.poll() is not None:
                    print("%s 已退出 (code=%s)，正在重启..."
                          % (role, proc.returncode), flush=True)
                    time.sleep(1)
                    procs[role] = [spawn(script, log_dir), script]
    except KeyboardInterrupt:
        print("\n正在关闭全部桌宠...", flush=True)
    finally:
        for role, (proc, _) in procs.items():
            if proc.poll() is None:
                proc.terminate()
        for role, (proc, _) in procs.items():
            try:
                proc.wait(timeout=5)
            except Exception:
                pass
        print("已全部退出。", flush=True)


if __name__ == "__main__":
    main()
