# -*- coding: utf-8 -*-
"""薄肌桌宠（邵艾伦，起头不接话）启动入口"""
import sys
import pet_engine

sys.argv = ["pet_engine.py", "--role", "shaolan"]
pet_engine.main()
