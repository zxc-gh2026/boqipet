# -*- coding: utf-8 -*-
"""峰哥桌宠（这是个好事）启动入口"""
import sys
import pet_engine

sys.argv = ["pet_engine.py", "--role", "fengge"]
pet_engine.main()
