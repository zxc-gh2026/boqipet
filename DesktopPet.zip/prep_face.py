#!/usr/bin/env python3
"""Deployment-time helper: flatten a PNG's alpha channel onto a solid magenta
background (exact #FF00FE) so that tkinter's -transparentcolor trick works.

Usage: python prep_face.py <input.png> <output.png> [ffmpeg.exe]
Pure stdlib only (zlib/struct). Decodes via ffmpeg to raw RGBA, composites with
integer math, writes an RGB PNG (color type 2). Transparent pixels become
exactly (255,0,254); semi-transparent pixels are alpha-blended over magenta.
"""
import struct, subprocess, sys, zlib, os

MAGENTA = (255, 0, 254)


def read_png_header(path):
    with open(path, "rb") as f:
        sig = f.read(8)
        assert sig == b"\x89PNG\r\n\x1a\n", "not a PNG"
        length = struct.unpack(">I", f.read(4))[0]
        ctype = f.read(4)
        assert ctype == b"IHDR", "no IHDR"
        data = f.read(length)
        w, h, bit, col = struct.unpack(">IIBB", data[:10])
        return w, h, bit, col


def dump_rgba(ffmpeg, src, dst, w, h):
    cmd = [ffmpeg, "-y", "-loglevel", "error", "-i", src,
           "-f", "rawvideo", "-pix_fmt", "rgba", dst]
    subprocess.run(cmd, check=True)
    raw = open(dst, "rb").read()
    assert len(raw) == w * h * 4, f"raw length {len(raw)} != {w*h*4}"
    return raw


def composite(raw, w, h):
    bg = MAGENTA
    out = bytearray(w * h * 3)
    for i in range(w * h):
        o = i * 4
        a = raw[o + 3]
        if a == 0:
            out[i * 3] = bg[0]; out[i * 3 + 1] = bg[1]; out[i * 3 + 2] = bg[2]
        else:
            inv = 255 - a
            out[i * 3]     = (raw[o] * a + bg[0] * inv + 127) // 255
            out[i * 3 + 1] = (raw[o + 1] * a + bg[1] * inv + 127) // 255
            out[i * 3 + 2] = (raw[o + 2] * a + bg[2] * inv + 127) // 255
    return bytes(out)


def chunk(tag, data):
    return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xffffffff)


def write_rgb_png(path, w, h, rgb):
    ihdr = struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)
    rows = bytearray()
    stride = w * 3
    for y in range(h):
        rows.append(0)
        rows += rgb[y * stride:(y + 1) * stride]
    png = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", ihdr)
    png += chunk(b"IDAT", zlib.compress(bytes(rows), 9))
    png += chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(png)


def main():
    src, dst = sys.argv[1], sys.argv[2]
    ffmpeg = sys.argv[3] if len(sys.argv) > 3 else "ffmpeg"
    w, h, bit, col = read_png_header(src)
    print(f"{os.path.basename(src)}: {w}x{h} bit={bit} colortype={col}")
    tmp = os.path.join(os.path.dirname(dst), "_raw_rgba.bin")
    try:
        raw = dump_rgba(ffmpeg, src, tmp, w, h)
        rgb = composite(raw, w, h)
        write_rgb_png(dst, w, h, rgb)
        print(f"wrote {dst} ({len(rgb)} bytes)")
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


if __name__ == "__main__":
    main()
