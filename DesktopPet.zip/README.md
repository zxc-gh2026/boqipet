# DesktopPet · 三人联动桌宠

Windows 桌面宠物：三只各有脾气的角色，支持 **UDP 本地联动接话**。
纯 Python + tkinter 实现，**零第三方依赖**（只用标准库 + Windows 自带 winmm）。

> 薄肌起头 → 孙哥接 → 峰哥接 → 孙哥再接 → 停。
> 点任意一只的头像，它会随机说一句话。

![三只桌宠](docs/preview.png)

---

## 角色

| 角色 | 台词风格 | UDP 端口 | 联动角色 | 台词数 |
|---|---|---|---|---|
| **薄肌**（邵艾伦） | 起头不接话，只说不接 | 5001 | 不接话，是联动的**起头人** | 37 |
| **孙哥**（太对了） | 回应"太对了" | 5002 | 听薄肌、峰哥，任何一方说都接 | 28 |
| **峰哥**（这是个好事） | 回应"这是个好事" | 5003 | 只听孙哥，且必须在薄肌起的这条链里 | 11 |

联动的"链"概念由消息里的 `root` / `hop` 字段维持：只有当消息的 `root` 是 `shaolan`（薄肌）时峰哥才会接话，且整条链最多跳 3 次，避免无限对话。

## 特性

- **透明背景**：`attributes("-transparentcolor", "#FF00FE")`，头像 PNG 的透明像素在部署时已铺成精确的 `#FF00FE`，播放时透掉
- **说话摇头**：只动窗口内的 Label，不动整个窗口，保证拖动时仍然可点中
- **台词气泡**：头顶弹出白色气泡显示台词，2.5 秒后自动消失
- **静音 / 调大小**：右键菜单可切换静音、调整头像尺寸（96 / 128 / 160 px）
- **启动动效**：先出现在屏幕中央 3 秒，再滑到右下角避开任务栏
- **单实例锁**：UDP 端口绑定天然互斥，同一角色开两个会失败
- **音频播放**：ctypes 直调 `winmm` 的 MCI 接口，无第三方音频库

## 环境要求

- Windows 10 / 11
- Python 3.8+（含 tkinter，官方安装包默认自带）
- **无需 pip install 任何东西**

## 快速开始

```bash
git clone <your-repo-url>
cd DesktopPet

# 单独启动一只
python sun_pet.py       # 孙哥
python feng_pet.py      # 峰哥
python shaolan_pet.py   # 薄肌

# 或者一键启动三只（推荐）
python launch_pets.py
```

启动后：屏幕中央出现头像，3 秒后滑到右下角。

### 交互

| 操作 | 效果 |
|---|---|
| 单击头像 | 随机播一句台词 |
| 按住拖动 | 移动桌宠位置 |
| 右键 | 打开菜单（随机说一句 / 静音 / 调大小 / 移回右下角 / 退出） |

## 项目结构

```
DesktopPet/
├── pet_engine.py          # 核心引擎：窗口、音频、联动、交互
├── sun_pet.py             # 孙哥入口（--role sunpet）
├── feng_pet.py            # 峰哥入口（--role fengge）
├── shaolan_pet.py         # 薄肌入口（--role shaolan）
├── launch_pets.py         # 一键启动三只
├── prep_face.py           # 部署工具：PNG 透明像素铺成洋红
├── SunPet/
│   └── Assets/
│       ├── clips.json     # 台词清单（id / 台词 / 文件名 / 时长）
│       ├── face_prep.png  # 运行时头像（已处理透明）
│       └── Clips/*.wav    # 音频
├── FengGe-Desktop-Pet/Assets/...
└── ShaolanPet/Assets/...
```

资源路径全部基于 `pet_engine.py` 所在目录（`ROOT_DIR`）相对解析，整个项目可以随意搬走。

### 台词配置

`clips.json` 每条记录：

```json
{
  "id": 1,
  "label": "你说太对了",     // 气泡显示的台词
  "file": "01.wav",          // 对应 Clips/ 下的音频
  "duration": 0.88,          // 时长（秒）
  "source": "https://..."    // 可选：出处，仅作溯源
}
```

`label` 缺失时引擎会退回显示文件名。`duration` 影响联动时下一只的等待节奏。

## 联动协议

每只桌宠绑定一个 UDP 端口，播完一句话后向 `127.0.0.1` 的 5001 / 5002 / 5003 广播：

```json
{"from": "shaolan", "clipID": 3, "duration": 2.58, "label": "...", "hop": 0, "root": "shaolan"}
```

- `hop`：当前是链上的第几跳，`hop >= 3` 时不再往下传
- `root`：起头者，峰哥据此判断"是不是薄肌起的头这条链"
- 收到自己的广播会忽略

## 重新生成头像

如果换了透明 PNG，需要重新铺洋红底：

```bash
python prep_face.py <input.png> <output.png> [ffmpeg路径]
```

脚本用 ffmpeg 解码成 RGBA，纯整数运算做 alpha 混合，输出 RGB PNG（color type 2）。

## 已知限制

- 仅 Windows：依赖 `winmm` MCI 音频接口和 tkinter 的 `-transparentcolor`
- 头像必须是不含洋红 `#FF00FE` 的实色内容，否则会被当成透明抠掉
- 三只必须跑在同一台机器（联动走 localhost UDP）

## License

MIT
