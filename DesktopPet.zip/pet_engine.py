#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
桌宠引擎（Windows 本地版，Python + tkinter，零第三方依赖）
================================================================
把 Ganzhe2028 的三个 macOS Swift 桌宠（SunPet 孙哥 / FengGe 峰哥 / ShaolanPet 薄肌）
用 Python + tkinter 重写，支持 U 三人联动对话。

特性（对应需求）：
  - 音频：ctypes 调 winmm MCI 接口播放 wav；m4a 已由部署脚本用 ffmpeg 转成 wav。
  - 透明背景：attributes("-transparentcolor", "#FF00FE")；
    头像 PNG 的透明像素已在部署时铺成精确 #FF00FE，播放时被透明掉。
  - 头像显示 128px（可右键调大小）。
  - 说话时头像左右晃（只动窗口内 Label，不动整个窗口，保证可点中），说完停。
  - 说话时头顶弹白色气泡显示台词，2.5 秒后自动消失。
  - 三人联动：薄肌起头(5001) -> 孙哥接(5002) -> 峰哥接(5003) -> 孙哥再接 -> 停。
    用 UDP localhost 实现：每只桌宠绑独立端口，播完向三个端口广播。
  - 点头像随机播一句；正在说话时不抢话。
  - 右键菜单：静音 / 调大小 / 退出。
  - 启动后先放屏幕中央 3 秒，再滑到右下角（避开任务栏）。

用法：python pet_engine.py --role sunpet|fengge|shaolan
"""
import ctypes
from ctypes import wintypes
import json
import math
import os
import random
import socket
import sys
import wave

import tkinter as tk

MAGENTA = "#FF00FE"
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

# 角色 -> (端口, 资源目录, 显示名, 头像默认宽, 听谁的话, 联动规则)
ROLES = {
    # 孙哥：听 薄肌、峰哥，任何一方说都接；hop<3 才接（第 4 跳封顶）
    "sunpet": dict(
        port=5002, res="SunPet", name="孙哥", label="太对了",
        avatar=128, peers=("shaolan", "fengge"), listen_rule="any_peer",
        companion_ids={1, 2, 4, 11, 13, 14}, overlap=0.3,
    ),
    # 峰哥：只听孙哥，且必须是在「薄肌起的头」这条链里；hop<3 才接
    "fengge": dict(
        port=5003, res="FengGe-Desktop-Pet", name="峰哥", label="这是个好事",
        avatar=128, peers=("sunpet",), listen_rule="root_shaolan",
        companion_ids=None, overlap=0.3,
    ),
    # 薄肌：只说不接（peers 为空），是联动的起头人
    "shaolan": dict(
        port=5001, res="ShaolanPet", name="薄肌", label="邵艾伦",
        avatar=128, peers=(), listen_rule="none",
        companion_ids=(), overlap=0.3,
    ),
}
# 联动广播目标：三个端口都发
ALL_PORTS = [5001, 5002, 5003]


# --------------------------------------------------------------------------
# winmm MCI 播放（ctypes，Windows 自带，零依赖）
# --------------------------------------------------------------------------
class MciPlayer:
    ALIAS = "petclip"

    def __init__(self):
        w = ctypes.windll.winmm
        w.mciSendStringW.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p,
                                     ctypes.c_uint, ctypes.c_void_p]
        w.mciSendStringW.restype = ctypes.c_uint
        w.mciGetErrorStringW.argtypes = [ctypes.c_uint, ctypes.c_wchar_p,
                                         ctypes.c_uint]
        w.mciGetErrorStringW.restype = ctypes.c_uint
        self.winmm = w

    def _send(self, cmd):
        """返回 (ok, text)；ok=False 时 text 为错误描述，True 时为命令返回文本"""
        buf = ctypes.create_unicode_buffer(512)
        rc = self.winmm.mciSendStringW(cmd, buf, 512, None)
        if rc:
            err = ctypes.create_unicode_buffer(512)
            self.winmm.mciGetErrorStringW(rc, err, 512)
            return False, err.value.strip()
        return True, buf.value.strip()

    def open_play(self, path, vol1000):
        self.close()
        path = path.replace('"', '')
        ok, txt = self._send('open "%s" type waveaudio alias %s' % (path, self.ALIAS))
        if not ok:
            return txt
        self._send("setaudio %s volume to %d" % (self.ALIAS, max(0, min(1000, vol1000))))
        self._send("play %s" % self.ALIAS)
        return None

    def mode(self):
        # 返回 None=出错/未开, 'playing', 'stopped', 'paused'...
        ok, txt = self._send("status %s mode" % self.ALIAS)
        return txt if ok else None

    def is_playing(self):
        return self.mode() == "playing"

    def stop(self):
        self._send("stop %s" % self.ALIAS)

    def close(self):
        self._send("close %s" % self.ALIAS)


# --------------------------------------------------------------------------
# 联动：UDP localhost
# --------------------------------------------------------------------------
class Linker:
    def __init__(self, role_cfg, on_spoke):
        self.cfg = role_cfg
        self.role = role_cfg["role"]
        self.on_spoke = on_spoke
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # 绑定自己端口即天然的单实例锁：同角色开两个会失败
        self.sock.bind(("127.0.0.1", role_cfg["port"]))
        self.sock.setblocking(False)
        self.tx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def broadcast(self, clip_id, duration, label, hop, root):
        msg = json.dumps({
            "from": self.role, "clipID": clip_id, "duration": duration,
            "label": label, "hop": hop, "root": root,
        }).encode("utf-8")
        for port in ALL_PORTS:
            try:
                self.tx.sendto(msg, ("127.0.0.1", port))
            except OSError:
                pass

    def poll(self):
        # 非阻塞收包，交给引擎处理
        while True:
            try:
                data, _ = self.sock.recvfrom(4096)
            except BlockingIOError:
                break
            except OSError:
                break
            try:
                msg = json.loads(data.decode("utf-8"))
            except Exception:
                continue
            if msg.get("from") == self.role:
                continue  # 忽略自己的广播
            self.on_spoke(msg)

    def close(self):
        try:
            self.sock.close()
            self.tx.close()
        except OSError:
            pass


# --------------------------------------------------------------------------
# 音频开头静音检测（读 wav 帧，纯 stdlib）
# --------------------------------------------------------------------------
def leading_silence(path):
    try:
        wf = wave.open(path, "rb")
        rate = wf.getframerate()
        ch = wf.getnchannels()
        sw = wf.getsampwidth()
        n = wf.getnframes()
        want = min(n, int(rate * 0.6))  # 只看前 0.6 秒
        frames = wf.readframes(want)
        wf.close()
    except Exception:
        return 0.0
    if sw == 2:
        import array
        samples = array.array("h")
        samples.frombytes(frames[: want * ch * sw])
        samples = list(samples)
    else:
        samples = list(frames)  # 8-bit 无符号，仅兜底
        ch = 1
    peak = max((abs(s) for s in samples), default=0)
    if peak <= 0:
        return 0.0
    th = max(0.004, peak * 0.06) / (32768 if sw == 2 else 255)
    # 逐样本（按通道取最大值）找第一个超过阈值的样本位置
    step = max(1, ch)
    for i in range(0, len(samples), step):
        block = samples[i:i + step]
        if any(abs(s) > th for s in block):
            return (i // step) / rate
    return 0.0


# --------------------------------------------------------------------------
# 主引擎
# --------------------------------------------------------------------------
class Pet:
    def __init__(self, role):
        cfg = dict(ROLES[role])
        cfg["role"] = role
        self.cfg = cfg
        self.assets = os.path.join(ROOT_DIR, cfg["res"], "Assets")
        self.log_path = os.path.join(ROOT_DIR, cfg["res"], "pet.log")
        self._log("启动 role=%s port=%d" % (role, cfg["port"]))

        # 音量 / 大小
        self.volume_pct = 65
        self.muted = False
        self.avatar = cfg["avatar"]
        self.SIZES = {"小": 96, "中": 128, "大": 160}

        # 状态
        self.playing = False
        self.bag = []
        self.last_clip = None
        self._shake_job = None
        self._bubble_job = None
        self._companion_after = None
        self._poll_job = None

        # 加载台词
        with open(os.path.join(self.assets, "clips.json"), "r", encoding="utf-8") as f:
            self.clips = json.load(f)
        self.companion_pool = (
            [c for c in self.clips if c["id"] in cfg["companion_ids"]]
            if cfg["companion_ids"] is not None else list(self.clips)
        )
        self.companion_bag = []
        self._lead_cache = {}

        # MCI + 联动
        self.player = MciPlayer()
        self.linker = Linker(cfg, self._on_spoke)

        # 窗口
        self._dpi_aware()
        self.root = tk.Tk()
        self.root.title("%s桌宠" % cfg["name"])
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.attributes("-transparentcolor", MAGENTA)
        self.root.configure(bg=MAGENTA)

        # 头像（PhotoImage 缩放）
        self._load_face()

        # 摇头动画用的 Label
        self.face_label = tk.Label(self.root, image=self.photo, bg=MAGENTA,
                                   cursor="hand2")
        self.face_label.place(x=self.margin, y=self.margin)
        self.face_label.bind("<Button-1>", self.on_press)
        self.face_label.bind("<B1-Motion>", self.on_drag)
        self.face_label.bind("<ButtonRelease-1>", self.on_release)
        self.face_label.bind("<Button-3>", self.on_right_click)
        self.root.bind("<Button-3>", self.on_right_click)

        # 窗口大小 = 头像 + 四周留白（摇不露边）
        self.win_w = self.photo.width() + 2 * self.margin
        self.win_h = self.photo.height() + 2 * self.margin
        self.root.geometry("%dx%d" % (self.win_w, self.win_h))

        # 气泡窗口
        self._build_bubble()

        # 屏幕与初始位置：先居中，3 秒后滑到右下角
        self.sw = self.root.winfo_screenwidth()
        self.sh = self.root.winfo_screenheight()
        cx = (self.sw - self.win_w) // 2
        cy = (self.sh - self.win_h) // 2 - 40
        self.root.geometry("+%d+%d" % (cx, cy))
        self.root.after(3000, self.slide_to_corner)

        # 联动 UDP 监听：启动后持续轮询（不依赖播放状态）
        self._poll_job = self.root.after(60, self._poll)

        self.root.protocol("WM_DELETE_WINDOW", self.quit)

    # ---------------- 系统 ----------------
    def _dpi_aware(self):
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass

    def _log(self, msg):
        try:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write("%s %s\n" % (time_str(), msg))
        except Exception:
            pass

    def _load_face(self):
        path = os.path.join(self.assets, "face_prep.png")
        base = tk.PhotoImage(file=path)
        target = self.avatar
        w, h = base.width(), base.height()
        if w and w != target:
            if w > target:
                s = max(1, int(round(w / target)))
                base = base.subsample(s, s)
            else:
                s = max(1, int(round(target / w)))
                base = base.zoom(s, s)
        self.photo = base
        self.margin = 14

    def _build_bubble(self):
        self.bubble = tk.Toplevel(self.root)
        self.bubble.overrideredirect(True)
        self.bubble.attributes("-topmost", True)
        self.bubble.attributes("-transparentcolor", MAGENTA)
        self.bubble.configure(bg=MAGENTA)
        self.bubble.withdraw()
        self.bubble_label = tk.Label(self.bubble, bg="white", fg="#111111",
                                     font=("Microsoft YaHei UI", 11),
                                     padx=10, pady=5, wraplength=260,
                                     justify="left")
        self.bubble_label.pack()

    # ---------------- 位置 ----------------
    def _workarea(self):
        # 用 Windows 工作区（不含任务栏）
        try:
            r = wintypes.RECT()
            ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(r), 0)
            if r.right > r.left and r.bottom > r.top:
                return r.left, r.top, r.right, r.bottom
        except Exception:
            pass
        return 0, 0, self.sw, self.sh

    def slide_to_corner(self):
        l, t, r, b = self._workarea()
        tx = r - self.win_w - 8
        ty = b - self.win_h - 4
        cx = self.root.winfo_x()
        cy = self.root.winfo_y()
        steps = 24
        for i in range(1, steps + 1):
            k = i / steps
            k = k * k  # 缓出
            x = int(cx + (tx - cx) * k)
            y = int(cy + (ty - cy) * k)
            self.root.after(int(30 * i), lambda xx=x, yy=y: self.root.geometry("+%d+%d" % (xx, yy)))

    # ---------------- 播放 ----------------
    def _pick_clip(self):
        pool = self.clips
        ids = [c["id"] for c in pool]
        if not ids:
            return None
        # 一轮内不重复
        self.bag = [x for x in self.bag if x in ids]
        if not self.bag:
            self.bag = ids[:]
            random.shuffle(self.bag)
            if len(self.bag) > 1 and self.bag[-1] == self.last_clip:
                self.bag[0], self.bag[-1] = self.bag[-1], self.bag[0]
        cid = self.bag.pop()
        self.last_clip = cid
        return next(c for c in pool if c["id"] == cid)

    def _pick_companion(self):
        if not self.companion_pool:
            return None
        ids = [c["id"] for c in self.companion_pool]
        if not self.companion_bag:
            self.companion_bag = ids[:]
            random.shuffle(self.companion_bag)
        cid = self.companion_bag.pop()
        return next(c for c in self.companion_pool if c["id"] == cid)

    def _effective_volume(self):
        if self.muted:
            return 0
        return int(self.volume_pct * 10)

    def play(self, clip, hop=0, root=None, from_link=False):
        """播放一句；hop 与 root 只在联动传播时使用"""
        self._cancel_pending()
        clip_file = os.path.join(self.assets, "Clips", clip["file"])
        if not os.path.exists(clip_file):
            self._log("缺少音频 %s" % clip_file)
            self._show_bubble("音频缺失")
            return
        self.player.stop()
        err = self.player.open_play(clip_file, self._effective_volume())
        if err:
            self._log("播放失败 %s: %s" % (clip["file"], err))
            self._show_bubble("播放失败")
            return
        self.playing = True
        self.start_shake()
        duration = float(clip.get("duration", 1.0))
        self._show_bubble(clip["label"])
        self._log("play id=%s hop=%s root=%s %s" % (clip["id"], hop, root or self.cfg["role"], clip["label"]))
        # 广播联动（含 hop/root）
        root = root or self.cfg["role"]
        self.linker.broadcast(clip["id"], duration, clip["label"], hop, root)

    def _poll(self):
        self.linker.poll()
        if self.playing and not self.player.is_playing():
            # 播放结束
            self.playing = False
            self.stop_shake()
            self.player.close()
        self._poll_job = self.root.after(60, self._poll)

    def stop(self):
        self._cancel_pending()
        self.player.stop()
        self.player.close()
        self.playing = False
        self.stop_shake()
        if self._poll_job:
            try:
                self.root.after_cancel(self._poll_job)
            except Exception:
                pass
            self._poll_job = None

    # ---------------- 交互 ----------------
    def on_press(self, event):
        self._px=event.x_root
        self._py=event.y_root
        self._wx=self.root.winfo_x()
        self._wy=self.root.winfo_y()
        self._drag=False

    def on_drag(self, event):
        dx=event.x_root-self._px; dy=event.y_root-self._py
        if abs(dx)>4 or abs(dy)>4: self._drag=True
        if self._drag: self.root.geometry("+%d+%d"%(self._wx+dx,self._wy+dy))

    def on_release(self, event):
        if not getattr(self,"_drag",False): self.on_click()

    def on_click(self):
        if self.playing:
            return  # 正在说话不抢话
        clip = self._pick_clip()
        if clip:
            self.play(clip, hop=0, root=self.cfg["role"])

    def on_right_click(self, event):
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="%s · %s（%d句）" % (self.cfg["name"], self.cfg["label"], len(self.clips)),
                         state="disabled")
        menu.add_separator()
        menu.add_command(label="随机说一句", command=self.on_click)
        menu.add_command(label="取消静音" if self.muted else "静音",
                         command=self.toggle_mute)
        size_menu = tk.Menu(menu, tearoff=0)
        for name, val in self.SIZES.items():
            size_menu.add_command(label="%s（%dpx）" % (name, val),
                                  command=lambda v=val: self.set_size(v))
        menu.add_cascade(label="调大小", menu=size_menu)
        menu.add_command(label="移回屏幕右下角", command=self.slide_to_corner)
        menu.add_separator()
        menu.add_command(label="退出", command=self.quit)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def toggle_mute(self):
        self.muted = not self.muted
        if self.playing:
            self.player.stop()
            self.player.close()
            self.playing = False
            self.stop_shake()
            self._show_bubble("已静音" if self.muted else "已取消静音")

    def set_size(self, val):
        self.avatar = val
        self._load_face()
        self.face_label.configure(image=self.photo)
        self.win_w = self.photo.width() + 2 * self.margin
        self.win_h = self.photo.height() + 2 * self.margin
        x = self.root.winfo_x()
        y = self.root.winfo_y()
        self.root.geometry("%dx%d+%d+%d" % (self.win_w, self.win_h, x, y))
        self.face_label.place(x=self.margin, y=self.margin)

    # ---------------- 摇头动画 ----------------
    def start_shake(self):
        self.stop_shake()
        self._phase = 0.0
        self._shake()

    def _shake(self):
        amp = 6
        self._phase += 0.38
        dx = int(math.sin(self._phase) * amp)
        # 只动窗口内 Label，不动整个窗口
        self.face_label.place(x=self.margin + dx, y=self.margin)
        self._shake_job = self.root.after(33, self._shake)

    def stop_shake(self):
        if self._shake_job:
            try:
                self.root.after_cancel(self._shake_job)
            except Exception:
                pass
            self._shake_job = None
        if hasattr(self, "face_label"):
            self.face_label.place(x=self.margin, y=self.margin)

    # ---------------- 气泡 ----------------
    def _show_bubble(self, text):
        if self._bubble_job:
            try:
                self.root.after_cancel(self._bubble_job)
            except Exception:
                pass
            self._bubble_job = None
        self.bubble_label.config(text=text)
        self.bubble.update_idletasks()
        bw = self.bubble.winfo_reqwidth()
        bh = self.bubble.winfo_reqheight()
        px = self.root.winfo_rootx() + (self.win_w - bw) // 2
        py = self.root.winfo_rooty() - bh - 6
        if py < 0:
            py = self.root.winfo_rooty() + self.win_h + 6
        self.bubble.geometry("+%d+%d" % (px, py))
        self.bubble.deiconify()
        self.bubble.lift()
        # 2.5 秒后自动消失
        self._bubble_job = self.root.after(2500, self._hide_bubble)

    def _hide_bubble(self):
        self.bubble.withdraw()
        self._bubble_job = None

    # ---------------- 联动 ----------------
    def _on_spoke(self, msg):
        r = self.cfg["listen_rule"]
        hop = int(msg.get("hop", 0))
        root = msg.get("root", msg.get("from"))
        frm = msg.get("from")
        self._log("spoke from=%s hop=%s root=%s dur=%s label=%s" %
                  (frm, hop, root, msg.get("duration"), msg.get("label")))
        try:
            if r == "none":
                self._log("decide rule-none skip")
                return
            if hop >= 3:
                self._log("decide hop>=3 stop")
                return
            if r == "any_peer":
                if frm not in self.cfg["peers"]:
                    self._log("decide peer-not-listened skip")
                    return
            elif r == "root_shaolan":
                if not (frm == "sunpet" and root == "shaolan"):
                    self._log("decide not-root-shaolan skip")
                    return
            # 注意：这里【不】做「正在说话就跳过」。联动捧哏刻意叠着上一句尾音接，
            # 收到广播时自己往往还在播；是否叠上去在 _fire_companion 触发瞬间再判。
            clip = self._pick_companion()
            if not clip:
                self._log("decide no-companion skip")
                return
            duration = float(msg.get("duration", 1.0))
            lead = self._companion_lead(clip)
            overlap = 0.2 if hop == 1 else self.cfg["overlap"]
            delay = max(0.02, duration - overlap - lead)
            self._log("decide OK schedule hop+1=%s id=%s delay=%.2f" % (hop + 1, clip["id"], delay))
            if self._companion_after:
                try:
                    self.root.after_cancel(self._companion_after)
                except Exception:
                    pass
            self._companion_after = self.root.after(
                int(delay * 1000),
                lambda c=clip, h=hop + 1, rt=root: self._fire_companion(c, h, rt))
        except Exception as e:
            self._log("spoke-error %r" % (e,))

    def _fire_companion(self, clip, hop, root):
        self._companion_after = None
        if self.playing:
            self._log("companion skipped (self playing)")
            return
        self._log("companion fire hop=%s root=%s id=%s" % (hop, root, clip["id"]))
        self.play(clip, hop=hop, root=root, from_link=True)

    def _companion_lead(self, clip):
        f = os.path.join(self.assets, "Clips", clip["file"])
        if f not in self._lead_cache:
            self._lead_cache[f] = leading_silence(f)
        return self._lead_cache[f]

    def _cancel_pending(self):
        if self._companion_after:
            try:
                self.root.after_cancel(self._companion_after)
            except Exception:
                pass
            self._companion_after = None

    # ---------------- 生命周期 ----------------
    def quit(self):
        self._cancel_pending()
        self.stop()
        self.linker.close()
        try:
            self.root.destroy()
        except Exception:
            pass

    def run(self):
        self.root.mainloop()


def time_str():
    import datetime
    return datetime.datetime.now().strftime("%H:%M:%S")


def main():
    role = None
    if "--role" in sys.argv:
        i = sys.argv.index("--role")
        if i + 1 < len(sys.argv):
            role = sys.argv[i + 1]
    if role not in ROLES:
        sys.stderr.write("usage: python pet_engine.py --role sunpet|fengge|shaolan\n")
        sys.exit(2)
    pet = Pet(role)
    pet.run()


if __name__ == "__main__":
    main()
