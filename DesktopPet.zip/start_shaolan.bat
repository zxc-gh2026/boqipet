@echo off
REM 启动薄肌桌宠 —— 兼容 py 启动器与 PATH 上的 pythonw
setlocal
cd /d "%~dp0"

set "PYEXE="
where pyw >nul 2>&1 && set "PYEXE=pyw -3"
if not defined PYEXE (
    where pythonw >nul 2>&1 && set "PYEXE=pythonw"
)
if not defined PYEXE (
    echo [错误] 未找到 Python，请先安装 Python 3.8+ 并勾选 "Add to PATH"
    pause
    exit /b 1
)

start "" %PYEXE% shaolan_pet.py
exit /b 0
