# -*- coding: utf-8 -*-
"""孙哥桌宠（太对了）启动入口"""
import sys
import pet_engine

sys.argv = ["pet_engine.py", "--role", "sunpet"]
pet_engine.main()
